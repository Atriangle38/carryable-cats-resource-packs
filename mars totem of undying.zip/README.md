### questions
feel free to contact me on discord @Godlander#1020 or https://discord.gg/2s6th9SvZd

# contributors:
**DartCat25** - Helped me get started

**The Der Discohund** - Help with matrix operations

**Onnowhere** - Help with formatting decisions and testing

**Suso** - Idea for controlled interpolated animation

**Dominexis** - Help with spline math

**Barf Creations** - Help replicating Minecraft's jank Pose rotation matrix

**kumitatepazuru** - Adding command line arguments for the script

**Daminator** - Showing me tkinter (this is so painful why)

**thebbq** - Help with edge case hardware inconsistency debugging